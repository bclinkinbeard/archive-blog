var angular = require('angular'),
	$ = require('jquery');

module.exports = function () {
	console.log('this is just a demo');
};
